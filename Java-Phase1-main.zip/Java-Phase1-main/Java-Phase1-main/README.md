# Assessment1
Project Name :- Virtual Key for Your Repositories

                     Project and developer details 
                     
	This Project is going to perform File Handling Operations, where user can view them in ascending order and can add or delete a file. And search a particular file with the respective “keyword”.


            Sprints planned and the tasks achieved in them 
            
The Project is planned in One Sprint .  Task achieved in this Sprint are 

-> Created the flow of the application
-> Created  Git Repository
-> Development of the project
-> Tested the project on various kinds of inputs
-> Pushed the project onto my Github Repository
-> Created the Specification document, 
-> This highlights the appearance and UI of Application


Core concepts used in the project 
	
	-> File Handling, Exception Handling
	-> Input and Output Stream
	-> Flow Control
	->Looping Control



